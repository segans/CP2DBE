package com.fiap.checkpoint2;

public interface JpaRepository<T, T1> {
}
