package com.fiap.checkpoint2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Checkpoint2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
